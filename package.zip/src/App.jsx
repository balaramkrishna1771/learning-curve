import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import DropdownPage from './componets/DropdownPage.jsx';
import LandingPage from './componets/LandingPage.jsx';
import Dashboard from './componets/Dashboard.jsx';
import { SelectionProvider } from './componets/SelectionContext.jsx';
import './styles/global.css';
import LoginPage from './componets/LoginPage.jsx';
import { GoogleOAuthProvider } from '@react-oauth/google';
import Resources from "./componets/Resources";
import Timeline from "./componets/Timeline";
import Support from "./componets/Support";

function App() {
  const clientId = "398056349883-m7tb6cjjkkdipiirt1n4ti0e2ms5sghh.apps.googleusercontent.com";
  return (
    <SelectionProvider>
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route exact path="/dropdown" element={<DropdownPage />} />
          <Route exact path="/dashboard" element={<Dashboard />} />
          <Route exact path="/resources" element={<Resources />} />
          <Route exact path="/timeline" element={<Timeline />} />
          <Route exact path="/support" element={<Support />} />
          {/*<Route exact path="/"*/}
          <Route exact path='/login' element={
            <GoogleOAuthProvider clientId={clientId}> <LoginPage /> </GoogleOAuthProvider>
          } />

        </Routes>
      </Router>
    </SelectionProvider >
  );
}

export default App;

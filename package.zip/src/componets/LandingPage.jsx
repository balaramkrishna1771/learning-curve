import { useNavigate } from 'react-router-dom';

export default function LandingPage() {

    const navigate = useNavigate();

    return (
        <div className=" min-h-screen flex items-center justify-center">
            <div className="flex flex-col md:flex-row items-center max-w-5xl p-6 space-y-6 md:space-y-0 md:space-x-10">
                <div className="text-center md:text-left max-w-lg">
                    <h1 className="text-5xl font-bold mb-4">Our Purpose</h1>
                    <p className="text-xl mb-4">
                        An all-inclusive timeline and tracker to guide you into medical/dental school.
                    </p>
                    <p className="text-md text-gray-700">
                        How do I get into medical/dental school? What should I be doing right now?
                        How do I shadow?What’s the MCAT? DAT? It's a confusing and difficult path into
                        medicine & dentistry. We’re here to help organize that journey year-by-year,
                        step-by-step.
                    </p>
                    <p className="text-sm text-gray-700 leading-relaxed mt-2">
                        No matter what level of education you’re in, we’re here to give you all the
                        resources you’ll need to successfully get into medical/dental school!
                    </p>
                </div>

                <div className="flex justify-center items-center">
                    <div >
                        <p className='text-3xl'>Get<br />Started <button className="text-2xl" onClick={() => navigate('/dropdown')}>
                            &rarr;
                        </button>
                        </p>
                    </div>

                </div>
            </div>
        </div >
    );
}
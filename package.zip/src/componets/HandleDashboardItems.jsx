import React, { useState } from 'react';

const stages = [
    {
        id: 1,
        label: 'Freshman',
        description: ['Focus on classes', 'Begin extracurriculars', 'Begin volunteering', 'Major'],
    },
    {
        id: 2,
        label: 'Sophomore',
        description: ['Most important Sophomore year actions'],
    },
    {
        id: 3,
        label: 'Summer',
        description: ['Summer actions'],
    },
    {
        id: 4,
        label: 'Junior',
        description: ['Junior year actions'],
    },
    {
        id: 5,
        label: 'Summer',
        description: ['Summer between Junior and Senior'],
    },
    {
        id: 6,
        label: 'Senior',
        description: ['Senior year actions'],
    },
];

const Timeline = () => {
    const [activeStage, setActiveStage] = useState(1);

    return (
        <div className="min-h-screen flex flex-col items-center py-8">
            <h2 className="text-3xl font-bold mb-6">College/Undergraduate</h2>
            <div className="flex items-center mb-6 space-x-4">
                {stages.map((stage, index) => (
                    <div key={stage.id} className="flex items-center">
                        <button
                            onClick={() => setActiveStage(stage.id)}
                            className={`text-lg px-4 py-2 rounded-full ${
                                activeStage === stage.id
                                    ? 'bg-blue-500 text-white'
                                    : 'bg-gray-200 text-gray-700'
                            } focus:outline-none`}
                        >
                            {stage.label}
                        </button>
                        {index !== stages.length - 1 && (
                            <div className="w-10 h-1 bg-gray-400 mx-4"></div>
                        )}
                    </div>
                ))}
            </div>

            <div className="bg-white shadow-md p-6 rounded-lg w-80">
                {stages[activeStage - 1].description.map((desc, index) => (
                    <p key={index} className="mb-2 text-gray-700">
                        • {desc}
                    </p>
                ))}
            </div>

            <div className="flex justify-between mt-6 w-80">
                <button
                    onClick={() => setActiveStage((prev) => (prev > 1 ? prev - 1 : 1))}
                    disabled={activeStage === 1}
                    className="px-4 py-2 bg-gray-300 text-gray-700 rounded disabled:bg-gray-200"
                >
                    Previous
                </button>
                <button
                    onClick={() => setActiveStage((prev) => (prev < stages.length ? prev + 1 : stages.length))}
                    disabled={activeStage === stages.length}
                    className="px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-200"
                >
                    Next
                </button>
            </div>
        </div>
    );
};

export default Timeline;

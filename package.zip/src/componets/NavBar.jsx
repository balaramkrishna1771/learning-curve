import { Link } from 'react-router-dom';

export default function NavBar({ onLoginClick, isLoginActive }) {
    const buttonClassName = `m-0 p-4 justify-center hover:bg-stone-600 hover:text-stone-50 hover:pointer hover:border-1`;

    return (
        <div className="fixed flex justify-between items-center w-full shadow-md">
            <div className="text-left px-4 hover:pointer">
                <Link to="/">App Name</Link>
            </div>
            <div className="flex justify-end">
                <div className={buttonClassName}>
                    <Link to="/dashboard">My Dashboard</Link>
                </div>
                <div className={buttonClassName}>
                    <Link to="/timeline">Timeline</Link>
                </div>
                <div className={buttonClassName}>
                    <Link to="/resources">Resources</Link>
                </div>
                <div className={buttonClassName}>
                    <Link to="/support">Support</Link>
                </div>
                <div className={buttonClassName}>
                    {/*<button onClick={onLoginClick}>*/}
                    {/*    {isLoginActive ? <Link to="/">Home</Link> : "Login"}*/}
                    {/*</button>*/}
                    <Link to="/login">Login</Link>
                </div>
            </div>
        </div>
    );
}

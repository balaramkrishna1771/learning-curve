import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelection } from './SelectionContext.jsx';
import LoginPage from './LoginPage.jsx';

const options = [
    { label: 'Considering medicine, in high school', value: 'highschool' },
    { label: 'Applying to medicine, undergraduate', value: 'undergraduate' },
    { label: 'Applying to medicine, gap-year(s)', value: 'gapyear' },
    { label: 'Medical Student', value: 'medical' },
    { label: 'Dental Student', value: 'dental' },
];

const nextOptionsMap = {
    highschool: ['9th grade', '10th grade', '11th grade', '12th grade'],
    undergraduate: ['Freshman', 'Sophomore', 'Junior', 'Senior'],
    medical: ['First year', 'Second year', 'Third year', 'Fourth year'],
};

export default function DropdownPage() {
    const { selections, setSelections } = useSelection();
    const navigate = useNavigate();
    const [selectedOption, setSelectedOption] = useState('');
    const [nextOptions, setNextOptions] = useState([]);

    const handleFirstDropdownChange = (e) => {
        const value = e.target.value;
        setSelectedOption(value);
        setSelections((prev) => ({ ...prev, firstSelection: value }));
        setNextOptions(nextOptionsMap[value] || []);
    };

    const handleSecondSelection = (option) => {
        setSelections((prev) => ({ ...prev, secondSelection: option }));
        navigate('/login');
    };

    return (
        <div className="h-screen flex justify-center items-center">
            <div className="flex justify-between w-1/2">

                <div className="flex flex-col justify-center items-center">
                    <p className="text-3xl leading-tight">
                        Get<br />Started &rarr;
                    </p>
                </div>


                <div className="flex flex-col w-1/2">
                    <label className="text-md mb-2 block">WHAT DESCRIBES YOU BEST?</label>
                    <div className="relative inline-block w-full">
                        <select
                            className="appearance-none w-full bg-white border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded-full leading-tight focus:outline-none focus:shadow-outline"
                            value={selectedOption}
                            onChange={handleFirstDropdownChange}
                        >
                            <option value="" disabled>Select an option</option>
                            {options.map((option) => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))}
                        </select>
                        <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                            <svg className="fill-current h-4 w-4" viewBox="0 0 20 20">
                                <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                            </svg>
                        </div>
                    </div>


                    {nextOptions.length > 0 && (
                        <div className="flex flex-col space-y-4 mt-4">
                            {nextOptions.map((option, index) => (
                                <button
                                    key={index}
                                    onClick={() => handleSecondSelection(option)}
                                    className="bg-white border border-gray-300 text-gray-700 py-2 px-4 rounded-full text-center shadow-md hover:bg-gray-200 transition"
                                >
                                    {option}
                                </button>
                            ))}
                        </div>
                    )}
                </div>

            </div>

        </div>

    );
};



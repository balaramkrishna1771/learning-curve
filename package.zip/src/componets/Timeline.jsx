import NavBar from "./NavBar";
import React, { useState } from "react";
import TIMELINE_STAGES from '../timeline.json';

export default function Timeline() {
    const [activeSection, setActiveSection] = useState(null);
    const [gradeIndex, setGradeIndex] = useState(0);

    const toggleSection = (sectionName) => {
        if (activeSection === sectionName) {
            setActiveSection(null);
        } else {
            setActiveSection(sectionName);
            setGradeIndex(0); // Reset to first grade when changing section
        }
    };

    const handleNextGrade = (section) => {
        const grades = Object.keys(TIMELINE_STAGES[section]);
        if (gradeIndex < grades.length - 1) {
            setGradeIndex(gradeIndex + 1);
        }
    };

    const handlePreviousGrade = (section) => {
        if (gradeIndex > 0) {
            setGradeIndex(gradeIndex - 1);
        }
    };

    const renderGrade = (section) => {
        const grades = Object.keys(TIMELINE_STAGES[section]);
        const currentGrade = grades[gradeIndex];

        return (
            <>
                <h3 className="text-lg font-semibold mb-2">{currentGrade}</h3>
                <ul className="pl-4 text-sm text-gray-700 list-disc">
                    {TIMELINE_STAGES[section][currentGrade].map((item, idx) => (
                        <li key={idx}>{item}</li>
                    ))}
                </ul>
                <div className="flex justify-between mt-4">
                    <button
                        onClick={() => handlePreviousGrade(section)}
                        disabled={gradeIndex === 0}
                        className="px-4 py-2 bg-gray-200 rounded disabled:bg-gray-400"
                    >
                        Previous
                    </button>
                    <button
                        onClick={() => handleNextGrade(section)}
                        disabled={gradeIndex === grades.length - 1}
                        className="px-4 py-2 bg-gray-200 rounded disabled:bg-gray-400"
                    >
                        Next
                    </button>
                </div>
            </>
        );
    };

    return (
        <>
            <NavBar />
            <div className="min-h-screen flex flex-col gap-4 justify-center">

                {/* High School Section */}
                <div className="h-16 flex flex-row justify-center items-center border border-stone-400 rounded-xl mx-3">
                    <h2 className="text-xl font-semibold">High School</h2>
                    <button
                        onClick={() => toggleSection('HighSchool')}
                        className="text-xl transform transition-transform hover:rotate-180"
                    >
                        {activeSection === 'HighSchool' ? '▲' : '▼'}
                    </button>
                </div>
                {activeSection === 'HighSchool' && (
                    <div className="text-sm mx-3 mt-4 p-4 border border-stone-400 rounded-lg">
                        {renderGrade('HighSchool')}
                    </div>
                )}

                {/* College/Undergraduate Section */}
                <div className="h-16 flex flex-row justify-center items-center border border-stone-400 rounded-xl mx-3">
                    <h2 className="text-xl font-semibold">College/Undergraduate</h2>
                    <button
                        onClick={() => toggleSection('CollegeUndergraduate')}
                        className="text-xl transform transition-transform hover:rotate-180"
                    >
                        {activeSection === 'CollegeUndergraduate' ? '▲' : '▼'}
                    </button>
                </div>
                {activeSection === 'CollegeUndergraduate' && (
                    <div className="mx-3 mt-4 p-4 border border-stone-400 rounded-lg">
                        {renderGrade('CollegeUndergraduate')}
                    </div>
                )}

                {/* Medical/Dental School Section */}
                <div className="h-16 flex flex-row justify-center items-center border border-stone-400 rounded-xl mx-3">
                    <h2 className="text-xl font-semibold">Medical/Dental School</h2>
                    <button
                        onClick={() => toggleSection('MedicalDentalSchool')}
                        className="text-xl transform transition-transform hover:rotate-180"
                    >
                        {activeSection === 'MedicalDentalSchool' ? '▲' : '▼'}
                    </button>
                </div>
                {activeSection === 'MedicalDentalSchool' && (
                    <div className="mx-3 mt-4 p-4 border border-stone-400 rounded-lg">
                        {renderGrade('MedicalDentalSchool')}
                    </div>
                )}
            </div>
        </>
    );
}

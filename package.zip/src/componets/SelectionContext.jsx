import React, { createContext, useState, useContext } from 'react';

// Create the context
const SelectionContext = createContext();

// Custom hook to use the context
export const useSelection = () => useContext(SelectionContext);

// Context provider component
export const SelectionProvider = ({ children }) => {
    const [selections, setSelections] = useState({
        firstSelection: '',
        secondSelection: '',
        loginObj: ''
    });

    return (
        <SelectionContext.Provider value={{ selections, setSelections }}>
            {children}
        </SelectionContext.Provider>
    );
};

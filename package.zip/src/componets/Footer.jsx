export default function Footer({ onLoginClick, isLoginActive }) {
    return (
        <footer className="bg-stone-600 text-white py-6">
            <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">

                {/* Footer Branding */}
                <div className="mb-4 md:mb-0">
                    <p className="text-lg font-semibold">MediBuddy</p>
                    <p className="text-sm">© 2024 All Rights Reserved</p>
                </div>

                {/* Footer Links */}
                <div className="flex flex-wrap justify-center gap-4 text-sm">
                    <button onClick={onLoginClick} className="hover:text-gray-300">Dashboard</button>
                    <button onClick={onLoginClick} className="hover:text-gray-300">Resources</button>
                    <button onClick={onLoginClick} className="hover:text-gray-300">Calendar</button>
                    <button onClick={onLoginClick} className="hover:text-gray-300">Careers</button>
                    <button onClick={onLoginClick} className="hover:text-gray-300">Contact</button>
                </div>

                {/* Footer Login/Home Button */}
                <div className="mt-4 md:mt-0">
                    <button
                        onClick={onLoginClick}
                        className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-md text-sm"
                    >
                        {isLoginActive ? "Home" : "Login"}
                    </button>
                </div>
            </div>
        </footer>
    );
}

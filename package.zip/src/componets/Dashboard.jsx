import React, { useState } from 'react';
import { useSelection } from './SelectionContext';
import NavBar from './NavBar';
import { Link } from 'react-router-dom';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import CHANGE_ICON from '../resources/media/icons8-change-50.png';
import jsPDF from 'jspdf';

const PREV_YEAR_ITEMS = [
    { id: 1, item: 'Previous Year Item 1', done: false },
    { id: 2, item: 'Previous Year Item 2', done: false },
    { id: 3, item: 'Previous Year Item 3', done: false },
];

const CURR_YEAR_ITEMS = [
    { id: 1, item: 'Current Year Item 1', done: false },
    { id: 2, item: 'Current Year Item 2', done: false },
    { id: 3, item: 'Current Year Item 3', done: false },
];

const Dashboard = () => {
    const { selections } = useSelection();
    const [showPrevYearDropdown, setShowPrevYearDropdown] = useState(false);
    const [showCurrYearDropdown, setShowCurrYearDropdown] = useState(false);
    const [selectedPrevYearItemId, setSelectedPrevYearItemId] = useState(null);
    const [selectedCurrYearItemId, setSelectedCurrYearItemId] = useState(null);
    const [prevYearItems, setPrevYearItems] = useState(PREV_YEAR_ITEMS);
    const [currYearItems, setCurrYearItems] = useState(CURR_YEAR_ITEMS);
    const [editValue, setEditValue] = useState('');
    const [selectedDate, setSelectedDate] = useState(null);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);

    const handleEdit = (item, isPrevYear) => {
        const items = isPrevYear ? prevYearItems : currYearItems;
        const itemToEdit = items.find((i) => i.id === item.id);
        if (itemToEdit) {
            setEditValue(itemToEdit.item);
        }
    };

    const handleUpdate = (itemId, isPrevYear) => {
        const setItems = isPrevYear ? setPrevYearItems : setCurrYearItems;
        const updatedItems = (isPrevYear ? prevYearItems : currYearItems).map((item) =>
            item.id === itemId ? { ...item, item: editValue } : item
        );
        setItems(updatedItems);
        setEditValue('');
        isPrevYear ? setSelectedPrevYearItemId(null) : setSelectedCurrYearItemId(null);
    };

    const handleDelete = () => {
        if (itemToDelete) {
            const isPrevYear = prevYearItems.some(item => item.id === itemToDelete);
            const setItems = isPrevYear ? setPrevYearItems : setCurrYearItems;
            const updatedItems = (isPrevYear ? prevYearItems : currYearItems).filter((item) => item.id !== itemToDelete);
            setItems(updatedItems);
            setItemToDelete(null);
            setShowDeleteConfirmation(false);
        }
    };

    const toggleEditDelete = (item, isPrevYear) => {
        const setSelectedItemId = isPrevYear ? setSelectedPrevYearItemId : setSelectedCurrYearItemId;
        const selectedItemId = isPrevYear ? selectedPrevYearItemId : selectedCurrYearItemId;

        if (selectedItemId === item.id) {
            setSelectedItemId(null);
            setEditValue('');
        } else {
            setSelectedItemId(item.id);
            setEditValue(item.item);
        }
    };

    const confirmDelete = (itemId) => {
        setItemToDelete(itemId);
        setShowDeleteConfirmation(true);
    };

    const toggleDone = (itemId, isPrevYear) => {
        const setItems = isPrevYear ? setPrevYearItems : setCurrYearItems;
        const updatedItems = (isPrevYear ? prevYearItems : currYearItems).map(item =>
            item.id === itemId ? { ...item, done: !item.done } : item
        );
        setItems(updatedItems);
    };

    const exportToPDF = () => {
        const doc = new jsPDF();
        doc.text('Previous Year Items:', 10, 10);
        prevYearItems.forEach((item, index) => {
            doc.text(`${index + 1}. ${item.item} - ${item.done ? "Done" : "Pending"}`, 10, 20 + (index * 10));
        });
        doc.text('Current Year Items:', 10, 20 + (prevYearItems.length * 10) + 10);
        currYearItems.forEach((item, index) => {
            doc.text(`${index + 1}. ${item.item} - ${item.done ? "Done" : "Pending"}`, 10, 30 + (prevYearItems.length * 10) + (index * 10));
        });
        doc.save('items.pdf');
    };

    return (
        <>
            <NavBar />
            <div className="w-2/3 pt-16 px-8 min-h-screen">
                <h2 className="text-2xl font-semibold mb-4">
                    Welcome {selections.loginObj.given_name}
                </h2>
                <h3 className="flex items-center mb-4">
                    <strong>Stage: </strong>&nbsp;{selections.firstSelection}, {selections.secondSelection}.
                    <Link to="/dropdown">
                        <img
                            className="h-4 w-4 ml-2 inline-block hover:cursor-pointer"
                            src={CHANGE_ICON}
                            alt="Change Stage"
                            title="Change Stage"
                        />
                    </Link>
                </h3>

                {/* Set Change Date Button */}
                <button
                    onClick={() => setShowDatePicker(true)}
                    className="px-4 py-2 border border-stone-400 rounded"
                >
                    Set Change Date
                </button>

                {/* Date Picker Modal */}
                {showDatePicker && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
                        <div className="bg-white p-6 rounded shadow-lg">
                            <h3 className="text-lg font-semibold mb-4">Select a Date</h3>
                            <DatePicker
                                selected={selectedDate}
                                onChange={(date) => setSelectedDate(date)}
                                dateFormat="MM/dd/yyyy"
                                className="border p-2 rounded"
                                placeholderText="Click to select a date"
                            />
                            <div className="mt-4 flex justify-end space-x-4">
                                <button
                                    onClick={() => setShowDatePicker(false)}
                                    className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition"
                                >
                                    Close
                                </button>
                                <button
                                    onClick={() => {
                                        // Save the date (implement your logic here)
                                        setShowDatePicker(false);
                                    }}
                                    className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
                                >
                                    Save
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Previous Year Items */}
                <div className="border border-stone-400 rounded-md p-4 shadow-md mt-4">
                    <div className="flex flex-row justify-between items-center p-2 rounded-t-md">
                        <h2 className="text-lg font-semibold">Previous Year(s) Items <span
                            className="text-xs border border-black rounded-2xl" title="Items here are goals that should already be completed by now.">?</span></h2>
                        <button
                            onClick={() => setShowPrevYearDropdown(!showPrevYearDropdown)}
                            className="text-xl transform transition-transform hover:rotate-180"
                        >
                            {showPrevYearDropdown ? '▲' : '▼'}
                        </button>
                    </div>

                    {showPrevYearDropdown && (
                        <ul className="p-4">
                            {prevYearItems.map((item) => (
                                <li key={item.id} className="flex flex-row justify-between items-center p-2">
                                    <input
                                        type="checkbox"
                                        checked={item.done}
                                        onChange={() => toggleDone(item.id, true)}
                                        className="mr-2"
                                    />
                                    {selectedPrevYearItemId === item.id ? (
                                        <>
                                            <input
                                                type="text"
                                                value={editValue}
                                                onChange={(e) => setEditValue(e.target.value)}
                                                className="border border-gray-300 rounded px-2 py-1"
                                            />
                                            <div className="space-x-2">
                                                <button
                                                    onClick={() => handleUpdate(item.id, true)}
                                                    className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
                                                >
                                                    Save
                                                </button>
                                                <button
                                                    onClick={() => confirmDelete(item.id)}
                                                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition"
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </>
                                    ) : (
                                        <>
                                            <span className={item.done ? 'line-through' : ''}>{item.item}</span>
                                            <button
                                                onClick={() => toggleEditDelete(item, true)}
                                                className="text-gray-600 hover:text-gray-900"
                                            >
                                                •••
                                            </button>
                                        </>
                                    )}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                {/* Current Year Items */}
                <div className="border border-stone-400 rounded-md p-4 shadow-md mt-4">
                    <div className="flex flex-row justify-between items-center p-2 rounded-t-md">
                        <h2 className="text-lg font-semibold">Current Year Items <span
                            className="text-xs border border-black rounded-2xl" title="Items here are to be completed this year.">?</span></h2>
                        <button
                            onClick={() => setShowCurrYearDropdown(!showCurrYearDropdown)}
                            className="text-xl transform transition-transform hover:rotate-180"
                        >
                            {showCurrYearDropdown ? '▲' : '▼'}
                        </button>
                    </div>

                    {showCurrYearDropdown && (
                        <ul className="p-4">
                            {currYearItems.map((item) => (
                                <li key={item.id} className="flex flex-row justify-between items-center p-2">
                                    <input
                                        type="checkbox"
                                        checked={item.done}
                                        onChange={() => toggleDone(item.id, false)}
                                        className="mr-2"
                                    />
                                    {selectedCurrYearItemId === item.id ? (
                                        <>
                                            <input
                                                type="text"
                                                value={editValue}
                                                onChange={(e) => setEditValue(e.target.value)}
                                                className="border border-gray-300 rounded px-2 py-1"
                                            />
                                            <div className="space-x-2">
                                                <button
                                                    onClick={() => handleUpdate(item.id, false)}
                                                    className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
                                                >
                                                    Save
                                                </button>
                                                <button
                                                    onClick={() => confirmDelete(item.id)}
                                                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition"
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </>
                                    ) : (
                                        <>
                                            <span className={item.done ? 'line-through' : ''}>{item.item}</span>
                                            <button
                                                onClick={() => toggleEditDelete(item, false)}
                                                className="text-sm text-blue-500 hover:underline"
                                            >
                                                Edit/Delete
                                            </button>
                                        </>
                                    )}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                {/* Delete Confirmation Modal */}
                {showDeleteConfirmation && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
                        <div className="bg-white p-6 rounded shadow-lg">
                            <h3 className="text-lg font-semibold mb-4">Are you sure you want to delete this item?</h3>
                            <div className="flex justify-end space-x-4">
                                <button
                                    onClick={() => setShowDeleteConfirmation(false)}
                                    className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 transition"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={handleDelete}
                                    className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition"
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Export to PDF Button */}
                <button
                    onClick={exportToPDF}
                    className="px-4 py-2 mt-10 border border-stone-400 rounded cursor-pointer"
                >
                    Export to PDF
                </button>
            </div>
        </>
    );
};

export default Dashboard;

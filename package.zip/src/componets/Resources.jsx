import NavBar from "./NavBar";
import React, { useState } from "react";
import CHAT_LOGO from "../resources/media/chat.png";


export default function Resources() {
    const RESOURCE_OPTIONS = [
        "Extracurriculars",
        "Shadowing",
        "ACT/SAT help",
        "Common App/College Applications",
        "Shadowing",
        "Clinical Experience",
        "Research/Publications",
        "Studying Resources",
        "Other"
    ];

    const [openDropdowns, setOpenDropdowns] = useState([]);

    function handleToggleDropdown(idx) {
        setOpenDropdowns(prevState =>
            prevState.includes(idx)
                ? prevState.filter(item => item !== idx) // Close the dropdown if it's open
                : [...prevState, idx] // Open the dropdown
        );
    }

    return (
        <>
            <NavBar />
            <div className="min-h-screen gap-1 flex flex-col justify-start pt-16">
                <h2 className="mb-3 text-xl font-semibold">Resources</h2>
                {RESOURCE_OPTIONS.map((item, idx) => (
                    <div
                        key={idx}
                        className="w-1/2 p-3 ml-2 flex flex-row justify-between border border-stone-400"
                    >
                        <h2 className="text-lg font-semibold">{item}</h2>
                        <button
                            onClick={() => handleToggleDropdown(idx)}
                        >
                            {openDropdowns.includes(idx) ? '▲' : '▼'}
                        </button>
                        {openDropdowns.includes(idx) && (
                            <div className="mt-2">
                                {/* Dropdown content goes here */}
                                <p>Details about {item}</p>
                            </div>
                        )}
                    </div>
                ))}
                <div className="flex flex-row justify-end">
                    <img src={CHAT_LOGO} className="h-10 w-10"/>
                    <button>Click here to Chat</button>
                </div>
            </div>

        </>
    );
}

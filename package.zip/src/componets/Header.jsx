export default function Hedaer() {
    return <>
        <h1>This is the First React App </h1>
    </>
}
export default function Support(){
    return<>
        This is support page
    </>
}